# Drone PID Control Simulation in MATLAB

This project demonstrates the design and simulation of a PID controller for a drone altitude control system using MATLAB.

---

# Project Overview

The system models a drone using a second-order transfer function and applies a PID controller to improve:

- Stability
- Rise time
- Overshoot
- Disturbance rejection

The simulation includes:

1. Closed-loop step response
2. Performance analysis using `stepinfo`
3. Disturbance response analysis

---

# Transfer Function

The drone model is defined as:

G(s)=1/(s^2 + 2s + 5)

MATLAB representation:

```matlab
num = [1];
den = [1 2 5];
G = tf(num, den);
```

---

# PID Controller

Controller parameters:

| Parameter | Value |
|---|---|
| Kp | 18 |
| Ki | 10 |
| Kd | 4 |

MATLAB:

```matlab
C = pid(Kp, Ki, Kd);
```

---

# Closed Loop System

The closed-loop transfer function is generated using unity feedback:

```matlab
T = feedback(C*G,1);
```

---

# Simulations Performed

## 1. Step Response

The system response to a unit step input is plotted using:

```matlab
step(T);
```

This helps analyze:
- Rise time
- Settling time
- Overshoot
- Steady-state error

---

## 2. Performance Metrics

Performance parameters are obtained using:

```matlab
info = stepinfo(T)
```

Typical outputs include:
- RiseTime
- SettlingTime
- Overshoot
- Peak
- PeakTime

---

## 3. Disturbance Analysis

A disturbance is introduced at:

t = 5 seconds

Disturbance magnitude:

0.3

Simulation is performed using:

```matlab
lsim(T,u+d,t);
```

This evaluates the disturbance rejection capability of the PID controller.

---

# How to Run

1. Open MATLAB
2. Copy the script into a new `.m` file
3. Save the file
4. Run the script

Example:

```matlab
run('drone_pid_control.m')
```

---

# Expected Outputs

The program generates:

- Closed-loop step response graph
- Disturbance response graph
- System performance metrics in command window

---

# Applications

This project can be extended for:

- Drone altitude control
- Quadrotor stabilization
- Autonomous flight systems
- Control systems learning
- PID tuning experiments

---

# Future Improvements

Possible enhancements:

- Automatic PID tuning
- State-space modeling
- Nonlinear drone dynamics
- Simulink implementation
- Real-time hardware testing

---

# Author

Drone PID Control Simulation using MATLAB Control System Toolbox.
