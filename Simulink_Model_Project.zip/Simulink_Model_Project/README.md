# Simulink PID Drone Control Project

This folder contains a MATLAB PID controller simulation for drone altitude control.

## Files Included

- `simulink_model.m` → MATLAB simulation script
- `README.md` → Project documentation

## Features

- PID Controller Design
- Closed Loop Step Response
- Disturbance Analysis
- Performance Metrics

## How to Run

1. Open MATLAB
2. Open `simulink_model.m`
3. Run the script

