clc;
clear;
close all;

% Transfer Function of Drone
num = [1];
den = [1 2 5];

G = tf(num, den);

% PID Controller Parameters
Kp = 18;
Ki = 10;
Kd = 4;

C = pid(Kp, Ki, Kd);

% Closed Loop System
T = feedback(C*G,1);

% Step Response
figure;
step(T);
grid on;
title('Closed Loop Step Response');

% Performance Parameters
info = stepinfo(T)

% Disturbance Analysis
t = 0:0.01:15;
u = ones(size(t));

% Disturbance at t = 5 sec
d = zeros(size(t));
d(t>=5) = 0.3;

[y,t] = lsim(T,u+d,t);

figure;
plot(t,y,'LineWidth',2);
grid on;
xlabel('Time (sec)');
ylabel('Altitude');
title('Response with Disturbance');
